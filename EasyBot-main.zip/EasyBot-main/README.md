### Big Credits to: PartyBot and mxnty.
# How to Install?
1. Create a https://repl.it Account.
2. Go to this Link https://repl.it/github/Aspect0002/EasyBot
3. Fill out the .env file. (DO NOT SHARE THE FILE)
4. Get an auth code from http://bit.ly/38URYTD and login with your bot account and enter the whole response.
5. Ye. Your Bot is online.


# 24/7 Support.
1. Do the HOW to INSTALL steps.
2. It open a nwe Windows with a link ex: example.replname.repl.co
3. Join our Discord: https://discord.gg/geHy3UFrsD
4. Go to #uptime annd write ?uptime (the url)
